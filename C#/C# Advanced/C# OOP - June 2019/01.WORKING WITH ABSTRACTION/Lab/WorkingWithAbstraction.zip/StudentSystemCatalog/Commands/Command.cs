﻿namespace StudentSystemCatalog.Commands
{
    public class Command
    {
        public string Name { get; set; }

        public string[] Arguments { get; set; }
    }
}
