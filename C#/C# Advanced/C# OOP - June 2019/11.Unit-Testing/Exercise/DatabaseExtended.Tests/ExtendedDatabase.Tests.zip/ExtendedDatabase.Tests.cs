using NUnit.Framework;
using System;

namespace Tests
{
    [TestFixture]
    public class ExtendedDatabaseTests
    {
        private ExtendedDatabase dbPerson;
        private Person person;
        
        [SetUp]
        public void Setup()
        {
            this.person = new Person(1, "Ivan");
            this.dbPerson = new ExtendedDatabase(person);
        }

        [Test]
        public void TestIfConstructorWorksCorrectly()
        {
            int expectedCount = 1;

            Assert.AreEqual(expectedCount, this.dbPerson.Count);
        }

        [Test]
        public void AddMethodShoulThrowExceptionWithInvalidParameter()
        {
            for (int i = 2; i < 17; i++)
            {
                person = new Person(i, $"Sasho{i}");
                this.dbPerson.Add(person);
            }
            person = new Person(18, $"Sasho18");

            Assert.Throws<InvalidOperationException>(() => this.dbPerson.Add(person));
        }



        [Test]
        [TestCase(2, "Ivan")]
        [TestCase(1, "Pesho")]
        public void CheckIfCanAddUserThatAlreadyExist(int id, string name)
        {
            Person personToAdd = new Person(id, name);

            Assert.Throws<InvalidOperationException>(() => this.dbPerson.Add(personToAdd));
        }

        [Test]
        public void CheckRemoveFromDatabase()
        {
            this.dbPerson.Remove();

            Assert.Throws<InvalidOperationException>(() => this.dbPerson.Remove());
        }

        [Test]
        public void CheckFindByUsernameIfNoUserExistWithThatNameOrParameterIsNull()
        {
            Assert.Throws<InvalidOperationException>(() => this.dbPerson.FindByUsername("Sasho"));
        }

        [Test]
        public void CheckFindByUsernameIfSearchParameterIsNull()
        {
            Assert.Throws<ArgumentNullException>(() => this.dbPerson.FindByUsername(null));
        }

        [Test]
        public void FindByIdIfSearchIdIsNotFound()
        {
            Assert.Throws<InvalidOperationException>(() => this.dbPerson.FindById(2));
        }

        [Test]
        public void FindByIdIfIdIsNegative()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => this.dbPerson.FindById(-1));
        }
    }
}
