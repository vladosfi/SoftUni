﻿namespace ViceCity.Core.Contracts
{
    interface IEngine
    {
        void Run();
    }
}
