﻿namespace ViceCity.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
