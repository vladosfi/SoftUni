﻿namespace P03_SalesDatabase.Data
{
    public class Config
    {
        public const string ConnectionString = "Server=.\\SQLEXPRESS;Database=Hospital;Integrated Security=true;";
    }
}
