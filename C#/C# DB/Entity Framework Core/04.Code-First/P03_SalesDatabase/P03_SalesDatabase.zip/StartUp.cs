﻿namespace P03_SalesDatabase
{
    using Data;

    public class StartUp
    {
        public static void Main()
        {
            var db = new SalesContext();
        }
    }
}
