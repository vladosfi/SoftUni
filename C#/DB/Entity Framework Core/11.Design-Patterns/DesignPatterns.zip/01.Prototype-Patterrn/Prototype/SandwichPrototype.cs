﻿namespace PrototypePattern
{
    public abstract class SandwichPrototype
    {
        public abstract SandwichPrototype Clone();
    }
}
