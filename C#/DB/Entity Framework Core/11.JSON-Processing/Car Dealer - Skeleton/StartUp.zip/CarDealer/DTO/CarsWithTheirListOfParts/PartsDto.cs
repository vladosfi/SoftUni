﻿namespace CarDealer.DTO
{
    public class PartsDto
    {
        public string Name { get; set; }

        public string Price { get; set; }
    }
}
