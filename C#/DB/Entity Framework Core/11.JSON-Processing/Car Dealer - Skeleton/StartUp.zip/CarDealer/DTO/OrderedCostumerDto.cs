﻿namespace CarDealer.DTO
{
    public class OrderedCostumerDto
    {
        public string Name { get; set; }

        public string BirthDate { get; set; }

        public bool IsYoungDriver { get; set; }
    }
}
