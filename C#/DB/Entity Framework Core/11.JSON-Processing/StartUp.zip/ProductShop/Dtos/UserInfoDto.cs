﻿namespace ProductShop.Dtos
{
    public class UserInfoDto
    {
        public int Count { get; set; }

        public UserDetailsDto[] Users { get; set; }
    }
}
