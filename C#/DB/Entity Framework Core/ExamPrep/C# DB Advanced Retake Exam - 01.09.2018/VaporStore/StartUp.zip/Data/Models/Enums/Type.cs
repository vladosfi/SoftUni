﻿namespace VaporStore.Data.Models.Enums
{
    public enum Type
    {
        Debit = 0,
        Credit = 1
    }
}
