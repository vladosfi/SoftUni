﻿namespace PetClinic.Models
{
    public class Animal
    {
        
    }
}
