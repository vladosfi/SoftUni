﻿namespace CompetitorEntries.Models
{
    public class Competitor
    {
       // TODO: Implement me
    }
}
