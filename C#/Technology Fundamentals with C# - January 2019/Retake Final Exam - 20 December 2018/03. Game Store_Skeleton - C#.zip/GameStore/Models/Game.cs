﻿using System.ComponentModel.DataAnnotations;

namespace GameStore.Models
{
    public class Game
    {
        //TODO: Implement me ...
    }
}
